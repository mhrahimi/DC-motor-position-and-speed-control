/*****************************************************
This program was produced by the
CodeWizardAVR V2.05.3 Standard
Automatic Program Generator
� Copyright 1998-2011 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version : 
Date    : 2/6/2017
Author  : Rahimi
Company : 
Comments: 


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 1.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*****************************************************/

#include <mega32.h>

#include <delay.h>


#define ADC_VREF_TYPE 0x20

#define Kp 10
#define Ka 0.0001
#define Kv 1


int Left,Right,Middle,MotorZero;
float MotorState=0,VolumeState;
//int MotorState=0,VolumeState;
int Distance(int x,int y)
{
    if(x<=y)
        return y-x;
    else 
        return 4-x+y;
}
//Duty Cycle Calculator for Speed control
int DutyCycleCalculator(int CurrentADC)
{
    int diff,all,x;
    if(CurrentADC<Middle)
    {
        diff=Middle-CurrentADC;
        all=Middle-Left;
    }
    if(Middle<CurrentADC)  
    {
        diff=CurrentADC-Middle;
        all=Right-Middle;
    }
    
    //x=((diff/all)*256)-1;
    x=diff*256;
    x=x/all;
    x=x-1;
    if(x<0)
        x=-1*x;
    return x;
}
//Duty Cycle Calculator for position control
int DutyCycleCalculator2(int Last,int current)
{
    int x;
    x=Kp*(VolumeState-MotorState);
    if(x<0)
        x=-1*x;
    x=x+(Ka*10000*(current-Last));
    x=x+(Kv*(current-Last)*(3/4));    
    return x;    
}

// Read the 8 most significant bits
// of the AD conversion result
unsigned char read_adc(unsigned char adc_input)
{
ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSRA|=0x40;
// Wait for the AD conversion to complete
while ((ADCSRA & 0x10)==0);
ADCSRA|=0x10;
return ADCH;
}

int Calibrator()
{
    int x=0;
    while(PINB.0==1);   //waiting for pushing of calibration button  
    //Calibrating
    x=read_adc(0);
    while(PINB.0==0)
    {               
        x=(x+read_adc(0))/2;
    }    
    return x;
}
// Declare your global variables here









void main(void)
{
int CurrentADC,MotorCurrentPosition,MotorLastPosition,LastDirection;
// Declare your local variables here

// Input/Output Ports initialization
// Port A initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTA=0x00;
DDRA=0x00;

// Port B initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTB=0x3;
DDRB=0x08;

// Port C initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTC=0x00;
DDRC=0xFF;

// Port D initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In 
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T 
PORTD=0x00;
DDRD=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=0xFF
// OC0 output: Disconnected
TCCR0=0x6A;
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer1 Stopped
// Mode: Normal top=0xFFFF
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer2 Stopped
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=0x00;
MCUCSR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// USART initialization
// USART disabled
UCSRB=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 7.813 kHz
// ADC Voltage Reference: AREF pin
// Only the 8 most significant bits of
// the AD conversion result are used
ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0x87;

// SPI initialization
// SPI disabled
SPCR=0x00;

// TWI initialization
// TWI disabled
TWCR=0x00;
 
        //Calibrating
        Middle=Calibrator();
        Left=Calibrator();
        Right=Calibrator();
        Calibrator();            
        

        while(PINB.1==1)
        {
            CurrentADC=read_adc(0);  
            if(CurrentADC==Middle)
            {
                PORTC.0=1;
                PORTC.1=1;
                OCR0=255;
            }  
            if(CurrentADC<Middle)
            {        
                PORTC.0=1;
                PORTC.1=0;
                OCR0=DutyCycleCalculator(CurrentADC);
            }   
            if(Middle<CurrentADC)
            {        
                PORTC.0=0;
                PORTC.1=1;
                OCR0=DutyCycleCalculator(CurrentADC);
            }         
                    
            
        }
        MotorZero=PIND.0+2*PIND.1;   
        MotorCurrentPosition=MotorZero;  
        while(PINB.1==0)
        {      
            
            MotorLastPosition=MotorCurrentPosition;
            MotorCurrentPosition=PIND.0+2*PIND.1;    
            VolumeState=90*(read_adc(0)-Middle)/(Middle-Right);
            if(MotorState<VolumeState)
            {
                PORTC.0=0;
                PORTC.1=1; 
                MotorState=MotorState+Distance(MotorLastPosition,MotorCurrentPosition);
                LastDirection=1; 
                OCR0=DutyCycleCalculator2(MotorLastPosition,MotorCurrentPosition);               
            }  
            if(MotorState>VolumeState)
            {
                PORTC.0=1;
                PORTC.1=0; 
                MotorState=MotorState-Distance(MotorLastPosition,MotorCurrentPosition);
                LastDirection=-1;
                OCR0=DutyCycleCalculator2(MotorLastPosition,MotorCurrentPosition);                 
            } 
            if(MotorState==VolumeState)
            {
                PORTC.0=1;
                PORTC.1=1;
                OCR0=255;
                //MotorState=MotorState-LastDirection*Distance(MotorLastPosition,MotorCurrentPosition);                 
            }                                          
        }
        


}
