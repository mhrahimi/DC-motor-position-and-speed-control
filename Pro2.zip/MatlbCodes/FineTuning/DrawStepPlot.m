function [  ] = DrawStepPlot( a,b,k )
    %H TF
    H1=tf([a 1],[1 0]);
    H2=tf([b 1],[1]);
    H=series(H1,H2);
    H=k*H;

    %G TF
    G=tf([2 4],[1 11 10]);

    OLTF=series((H+D),G);   %Open Loop TF
    CLTF=feedback(OLTF,1);  %Closed Loop TF
    step(CLTF);
    hold on


end

