syms a s t b k
F = (2*a*b*s^3+(4*a*b+2*b+2*a)*s^2+(4*a+4*b+2)*s+4)/((1+2*k*a*b)*s^3+(11+2*k*a+2*k*b+4*k*a*b)*s^2+(10+4*k*a*b)*s+4*k);
ilaplace(F, t)