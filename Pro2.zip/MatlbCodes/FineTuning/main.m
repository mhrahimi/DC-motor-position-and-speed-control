%PreDefine
a=1;
b=1;
k=1;
D=1;

Storage=zeros();
counter=1;
for a=0:.1:2
    for b=0:.1:2
        for k=0:.1:2
            %H TF
            H1=tf([a 1],[1 0]);
            H2=tf([b 1],[1]);
            H=series(H1,H2);
            H=k*H;

            %G TF
            G=tf([2 4],[1 11 10]);

            OLTF=series((H+D),G);   %Open Loop TF
            CLTF=feedback(OLTF,1);  %Closed Loop TF
            
            %Disturbation SS err &setteling time
            UnitStep=tf([1],[1 0]);
            Dans=G/(1+G*H);
            %err
            [y,t]=step(Dans);
            sserror=abs(1-y(end));
            %settelingtime
            DistInfo=stepinfo(Dans);
            
            
            
            StepInf=stepinfo(CLTF);
            Storage(counter,1)=a;
            Storage(counter,2)=b;
            Storage(counter,3)=k;
            Storage(counter,4)=StepInf.Overshoot;
            Storage(counter,5)=StepInf.SettlingTime;
            Storage(counter,6)=sserror;
            Storage(counter,7)=DistInfo.SettlingTime;
            
            %Check for problem's conditions
            if ((Storage(counter,6)<.001)&&(Storage(counter,7)<0.1)&&(Storage(counter,4)<.1)&&(Storage(counter,5)<5))
                Storage(counter,1)
                Storage(counter,2)
                Storage(counter,3)
                Storage(counter,8)=1;
            end
            counter=counter+1
            
            %step(CLTF)
        end
    end
end
%when calculation down
load gong.mat;
sound(y);