function [  ] = percentage( counter,approx,Stepping )
    clc();
    all=((2/Stepping)*approx+1)^3;
    disp(abs((counter/all)*100))
    disp('%')
    disp('of process had completed');   


end

